<?php

require_once '../models/humiditylist.php';
require_once '../models/temperaturelist.php';

// Set the name of the current page
$PAGE = 'index';

if(isset($_POST['setPoint'])) {
    $HUMIDITIES = new HumidityList(intval($_POST['point']));
    $TEMPERATURES = new TemperatureList(intval($_POST['point']));
} else {
    $HUMIDITIES = new HumidityList(1);
    $TEMPERATURES = new TemperatureList(1);
}

// Do the rendering of the page
include '../views/header.php';      // This requires the $PAGE variable
include '../views/main.php';        // This requires $PROMO_PRODUCTS and $OTHER_PRODUCTS
include '../views/footer.php';      // This has no variable requirements
