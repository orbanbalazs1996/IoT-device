<?php

// Set the name of the current page
$PAGE = '404';

// Do the rendering of the page
include '../views/header.php';      // This requires the $PAGE variable
include '../views/404.php';         // This has no variable requirements
include '../views/footer.php';      // This has no variable requirements