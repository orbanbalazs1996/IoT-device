<?php

require_once '../models/nameofpoint.php';

// Set the name of the current page
$PAGE = 'fooldal';

Point::find(1);


// Do the rendering of the page
include '../views/header.php';      // This requires the $PAGE variable
include '../views/main.php';  // This requires the $TEMPERATURES
include '../views/footer.php';      // This has no variable requirements