<?php

require_once '../models/humiditylist.php';

// Set the name of the current page
$PAGE = 'humidities';

if(isset($_POST['setPoint'])) {
    $HUMIDITIES = new HumidityList(intval($_POST['point']));
} else {
    $HUMIDITIES = new HumidityList(1);
}

// Do the rendering of the page
include '../views/header.php';      // This requires the $PAGE variable
include '../views/humidities.php';  // This requires the $HUMIDITIES
include '../views/footer.php';      // This has no variable requirements