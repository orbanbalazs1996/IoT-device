<?php

require_once '../models/db.php';
require_once '../models/temperature.php';

class TemperatureList {
    /** @var array<Temperature>  */
    protected $temperature;

    /** @var PDO  */
    private $conn;

    /**
     * HumidityList constructor.
     */
    public function __construct($meropont_id = 1) {
        // Initialize DB connection
        $db = DB::getInstance();
        $this->conn = $db->getConnection();

        // Select all humidities from DB
        $stmt = $this->conn->prepare('SELECT * FROM homerseklet WHERE meropont_id = :meropont_id order by date desc');
        $stmt->bindParam(':meropont_id', $meropont_id);
        $stmt->execute();

        $this->temperatures = [];

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $this->temperatures[] = new Temperature($row['id'], $row['meropont_id'], $row['date'], $row['ho_1'], $row['ho_2']);
        }
    }

    private function setTemperatureValues() {
        $temperatureValues = [];
        foreach ($this->temperatures as $key=>$temp) {
            array_push($temperatureValues, floatval($temp->getHo_1()));
            array_push($temperatureValues, floatval($temp->getHo_2()));
        }

        return $temperatureValues;
    }

    private function countLast() {
        $last1 =  $this->setTemperatureValues()[count($this->setTemperatureValues())-1];
        $last2 =  $this->setTemperatureValues()[count($this->setTemperatureValues())-2];

            return ($last1 + $last2) / 2;


    }

    /**
     * GETTERS
     */

    public function getTemperatures() {
        return $this->temperatures;

    }

    public function getMinimum() {
        return min($this->setTemperatureValues());
    }

    public function getMaximum() {
        return max($this->setTemperatureValues());
    }

    public function getAvg() {
        return array_sum($this->setTemperatureValues()) / count($this->setTemperatureValues());
    }

    public function getLast() {
        return $this->countLast();
    }
}