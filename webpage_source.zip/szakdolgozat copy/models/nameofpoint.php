<?php

require_once '../models/db.php';


class Point{
    /** @var int  */
    protected $id;

    /** @var string  */
    protected $name;

    public function __construct($id,$name) {
        $this->name = $name;
        $this->id = $id;

    }

    public static function find($id) {
        // Initialize DB connection
        $db = DB::getInstance();
        $conn = $db->getConnection();

        // Select all humidities from DB
        $stmt = $conn->prepare('SELECT * FROM meropont WHERE id = :id');
        $stmt->bindParam(':id', $id);
        $stmt->execute();

        if($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            return $row['name'];
        } else {
            return null;
        }
    }

}
?>

