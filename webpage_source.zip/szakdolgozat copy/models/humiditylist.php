<?php

require_once '../models/db.php';
require_once '../models/humidity.php';

class HumidityList {
    /** @var array<Humidity>  */
    protected $humidity;

    /** @var PDO  */
    private $conn;

    /**
     * HumidityList constructor.
     */
    public function __construct($meropont_id = 1) {
        // Initialize DB connection
        $db = DB::getInstance();
        $this->conn = $db->getConnection();

        // Select all humidities from DB
        $stmt = $this->conn->prepare('SELECT * FROM paratartalom WHERE meropont_id = :meropont_id order by date desc');
        $stmt->bindParam(':meropont_id', $meropont_id);
        $stmt->execute();

        $this->humidities = [];

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $this->humidities[] = new Humidity($row['id'], $row['meropont_id'], $row['date'], $row['paratartalom_1'], $row['paratartalom_2']);
        }
    }

    private function setHumidityValues() {
        $humidityValues = [];
        foreach ($this->humidities as $key=>$hum) {
            array_push($humidityValues, floatval($hum->getParatartalom_1()));
            array_push($humidityValues, floatval($hum->getParatartalom_2()));
        }

        return $humidityValues;
    }

    private function countLast() {
        $last1 =  $this->setHumidityValues()[count($this->setHumidityValues())-1];
        $last2 =  $this->setHumidityValues()[count($this->setHumidityValues())-2];
        return ($last1 + $last2) / 2;
    }

    /**
     * GETTERS
     */

    public function getHumidities() {
        return $this->humidities;
    }

    public function getMinimum() {
        return min($this->setHumidityValues());
    }

    public function getMaximum() {
        return max($this->setHumidityValues());
    }

    public function getAvg() {
        return array_sum($this->setHumidityValues()) / count($this->setHumidityValues());
    }

    public function getLast() {
        return $this->countLast();
    }
}