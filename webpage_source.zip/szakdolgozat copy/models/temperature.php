<?php

require_once '../models/db.php';

class Temperature {
    /** @var int  */
    protected $id;

    /** @var int  */
    protected $meropont_id;

    /** @var string  */
    protected $date;

    /** @var float  */
    protected $ho_1;

    /** @var float  */
    protected $ho_2;

    /**
     * Product constructor.
     * @param int $id
     * @param int $meropont_id
     * @param string $date
     * @param float $ho_1
     * @param float $ho_2
     */
    public function __construct($id, $meropont_id, $date, $ho_1, $ho_2) {
        $this->id          = $id;
        $this->meropont_id = $meropont_id;
        $this->date        = $date;
        $this->ho_1 = $ho_1;
        $this->ho_2 = $ho_2;
    }

    /**
     * Find a temperature in the DB by ID. The function returns the Temperature (as object) or null if ID not found
     * @param int $id
     * @return Temperature|null
     */
    public static function find($id) {
        // Initialize DB connection
        $db = DB::getInstance();
        $conn = $db->getConnection();

        // Select all humidities from DB
        $stmt = $conn->prepare('SELECT * FROM homerseklet WHERE id = :id');
        $stmt->bindParam(':id', $id);
        $stmt->execute();

        if($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            return new Temperature($row['id'], $row['meropont_id'], $row['date'], $row['ho_1'], $row['ho_2']);
        } else {
            return null;
        }
    }

    /**
     * GETTERS
     */

    public function getId() {
        return $this->id;
    }

    public function getMeropont_id() {
        return $this->meropont_id;
    }

    public function getDate() {
        return $this->date;
    }

    public function getHo_1() {
        return $this->ho_1;
    }

    public function getHo_2() {
        return $this->ho_2;
    }

}