<?php

require_once '../models/db.php';

class Humidity {
    /** @var int  */
    protected $id;

    /** @var int  */
    protected $meropont_id;

    /** @var string  */
    protected $date;

    /** @var float  */
    protected $paratartalom_1;

    /** @var float  */
    protected $paratartalom_2;

    /**
     * Product constructor.
     * @param int $id
     * @param int $meropont_id
     * @param string $date
     * @param float $paratartalom_1
     * @param float $paratartalom_2
     */
    public function __construct($id, $meropont_id, $date, $paratartalom_1, $paratartalom_2) {
        $this->id          = $id;
        $this->meropont_id = $meropont_id;
        $this->date        = $date;
        $this->paratartalom_1 = $paratartalom_1;
        $this->paratartalom_2 = $paratartalom_2;
    }

    /**
     * Find a humidity in the DB by ID. The function returns the Humidity (as object) or null if ID not found
     * @param int $id
     * @return Humidity|null
     */
    public static function find($id) {
        // Initialize DB connection
        $db = DB::getInstance();
        $conn = $db->getConnection();

        // Select all humidities from DB
        $stmt = $conn->prepare('SELECT * FROM paratartalom WHERE id = :id');
        $stmt->bindParam(':id', $id);
        $stmt->execute();

        if($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            return new Humidity($row['id'], $row['meropont_id'], $row['date'], $row['paratartalom_1'], $row['paratartalom_2']);
        } else {
            return null;
        }
    }

    /**
     * GETTERS
     */

    public function getId() {
        return $this->id;
    }

    public function getMeropont_id() {
        return $this->meropont_id;
    }

    public function getDate() {
        return $this->date;
    }

    public function getParatartalom_1() {
        return $this->paratartalom_1;
    }

    public function getParatartalom_2() {
        return $this->paratartalom_2;
    }

}