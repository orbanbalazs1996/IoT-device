


<?php
$ROUTE = $_GET['route'] ?? 'main';
$ROUTE = explode('/', $ROUTE);

//var_dump($route);

$__SERVER_ROOT = '/home/orbba2';
$__CLIENT_ROOT = '/webprog/~orbba2/';




//$request = $_SERVER['REQUEST_URI'];



switch ($ROUTE[0]) {
    case '/' :
        require '../controllers/index.php';
        break;
    case '' :
        require '../controllers/index.php';
        break;
    case 'fooldal' :
        require '../controllers/index.php';
        break;
    case 'paratartalom' :
        require '../controllers/humidities.php';
        break;
    case 'homerseklet' :
        require '../controllers/temperatures.php';
        break;
    case 'homerseklet_beillesztes' :
        require '../public/api/adatok/homerseklet.php';
        break;
    case 'paratartalom_beillesztes' :
        require '../public/api/adatok/paratartalom.php';
        break;
    default:
        http_response_code(404);
        require '../controllers/404.php';
        break;
}
?>