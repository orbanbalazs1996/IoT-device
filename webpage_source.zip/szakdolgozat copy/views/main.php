<?php
/** */
?>
<section class="my-5">
    <div class="container">
        <div class="row">
            <div class="col-md-4 offset-md-4">
                <h1 class="mb-4 text-center">Összesítés</h1>
                <form action="fooldal" method="post">
                    <div class="form-group">
                        <label for="point">Mérőpont:</label>
                        <select name="point" id="" class="form-control">
                            <option value="1">Konyha</option>
                            <option value="2">Hálószoba</option>
                            <option value="3">Ebédlő</option>
                            <option value="4">Nappali</option>
                            <option value="5">Előszoba</option>
                        </select>
                        <input type="submit" name="setPoint" class="btn btn-primary btn-block mt-2" value="Lekérés">
                    </div>
                </form>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-md-6">
                <h2 class="text-center mb-4">Hőméséklet</h2>
                <div style="overflow-x: auto;">
                    <table class="table table-striped">
                        <thead class="thead-dark">
                            <tr>
                                <th>Minimum</th>
                                <th>Maximum</th>
                                <th>Átlag</th>
                                <th>Utolsó mérés</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                print(
                                    '<tr>
                                        <td>'.$TEMPERATURES->getMinimum() .' °C</td>
                                        <td>'.$TEMPERATURES->getMaximum() .' °C</td>
                                        <td>'.$TEMPERATURES->getAvg() .' °C</td>
                                        <td>'.$TEMPERATURES->getLast() .' °C</td>
                                    </tr>'
                                );
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-md-6">
                <h2 class="text-center mb-4">Páratartalom</h2>
                <div style="overflow-x: auto;">
                    <table class="table table-striped">
                        <thead class="thead-dark">
                            <tr>
                                <th>Minimum</th>
                                <th>Maximum</th>
                                <th>Átlag</th>
                                <th>Utolsó mérés</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                print(
                                    '<tr>
                                        <td>'.$HUMIDITIES->getMinimum() .' %</td>
                                        <td>'.$HUMIDITIES->getMaximum() .' %</td>
                                        <td>'.$HUMIDITIES->getAvg() .' %</td>
                                        <td>'.$HUMIDITIES->getLast() .' %</td>
                                    </tr>'
                                );
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>