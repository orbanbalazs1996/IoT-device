<?php
/** */
?>
<section class="my-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="text-center">404</h1>
                <h3 class="text-center">Sajnos a keresett oldal nem található.</h3>
            </div>
        </div>
    </div>
</section>