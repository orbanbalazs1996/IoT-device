<?php
/** */
?>
<section class="my-5">
    <div class="container">
        <div class="row">
            <div class="col-md-4 offset-md-4">
                <h1 class="mb-4 text-center">Páratartalom</h1>
                <form action="paratartalom" method="post">
                    <div class="form-group">
                        <label for="point">Mérőpont:</label>
                        <select name="point" id="" class="form-control">
                            <option value="1">Konyha</option>
                            <option value="2">Hálószoba</option>
                            <option value="3">Ebédlő</option>
                            <option value="4">Nappali</option>
                            <option value="5">Előszoba</option>
                        </select>
                        <input type="submit" name="setPoint" class="btn btn-primary btn-block mt-2" value="Lekérés">
                    </div>
                </form>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-md-12">
                <div style="overflow-x: auto;">
                    <table class="table table-striped">
                        <thead class="thead-dark">
                            <tr>
                                <th>Azonosító</th>
                                <th>Mérőpont</th>
                                <th>Időpont</th>
                                <th>Páratartalom</th>
                                <th>Kontroll páratartalom</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                foreach ($HUMIDITIES->getHumidities() as $key=>$humidity) {
                                    print(
                                        '<tr>
                                            <td>'.$humidity->getId() .'</td>
                                            <td>'.$humidity->getMeropont_id() .'</td>
                                            <td>'.$humidity->getDate() .'</td>
                                            <td>'.$humidity->getParatartalom_1() .' %</td>
                                            <td>'.$humidity->getParatartalom_2() .' %</td>
                                        </tr>'
                                    );
                                }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>